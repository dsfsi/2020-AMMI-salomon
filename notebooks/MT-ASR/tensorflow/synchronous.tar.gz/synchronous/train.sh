export CUDA_VISIBLE_DEVICES=0,1,2,3

python ./run.py  \
    --worker_gpu=4 \
    --gpu_mem_fraction=0.95 \
    --data_dir=../data/tf_data_enfr \
    --vocab_src_size=30000  \
    --vocab_tgt_size=30000  \
    --vocab_src_name=en-fr.vocab \
    --vocab_tgt_name=en-fr.vocab \
    --hparams_set=transformer_params_base  \
    --train_steps=100000  \
    --keep_checkpoint_max=10  \
    --output_dir=train_models_enfr \
    --pretrain_output_dir=../data/train_models/pretrain_model 
